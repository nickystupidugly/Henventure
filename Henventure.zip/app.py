from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route("/")
def dashboard():
    return render_template("dashboard.html")

@app.route("/log_egg", methods=["POST"])
def log_egg():
    # Placeholder logic for logging egg count
    egg_count = request.form.get("egg_count")
    print(f"Eggs collected: {egg_count}")
    return redirect("/")

if __name__ == "__main__":
    app.run(debug=True)
